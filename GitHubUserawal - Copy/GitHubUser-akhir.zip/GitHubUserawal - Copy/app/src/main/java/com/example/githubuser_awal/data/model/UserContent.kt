package com.example.githubuser_awal.data.model

import com.example.githubuser_awal.data.model.User

data class UserContent(
    val items : ArrayList<User>


)
